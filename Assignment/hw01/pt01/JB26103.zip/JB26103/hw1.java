/**
 * @(#)hw1.java
 *
 *
 * @�}�ӧ� 
 * @version 1.00 2015/10/6
 */

public class hw1 {
	public static void main(String[] args) {
		System.out.println("Hello, World! �ڬO�}�ӧ�!");
	}
}