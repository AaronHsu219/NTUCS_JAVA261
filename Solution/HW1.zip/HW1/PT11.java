public class PT11 {
	public static void main(String[] args)
	{
		System.out.println("hello, world!");
	}
}